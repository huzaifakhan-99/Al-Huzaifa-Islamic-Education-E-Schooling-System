// ===== mobile nav toggle =====
const navToggle = document.getElementById('navToggle');
const mainNav = document.getElementById('mainNav');

navToggle.addEventListener('click', () => {
  const isOpen = mainNav.classList.toggle('open');
  navToggle.setAttribute('aria-expanded', String(isOpen));
});

mainNav.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    mainNav.classList.remove('open');
    navToggle.setAttribute('aria-expanded', 'false');
  });
});

// ===== pre-select course when "Enroll Now" is clicked on a course card =====
const courseSelect = document.getElementById('course');

document.querySelectorAll('[data-course]').forEach(btn => {
  btn.addEventListener('click', () => {
    const courseName = btn.getAttribute('data-course');
    if (courseSelect) {
      courseSelect.value = courseName;
    }
  });
});

// ===== enrollment form submit (front-end only, no backend wired up) =====
const enrollForm = document.getElementById('enrollForm');
const formFields = document.getElementById('formFields');
const formSuccess = document.getElementById('formSuccess');

enrollForm.addEventListener('submit', (e) => {
  e.preventDefault();

  if (!enrollForm.checkValidity()) {
    enrollForm.reportValidity();
    return;
  }

  // NOTE: This demo has no backend. Hook this up to your enrollment
  // API / email service / Google Sheet / CRM of choice, then replace
  // this block with the real submission logic.
  formFields.hidden = true;
  formSuccess.hidden = false;
  formSuccess.scrollIntoView({ behavior: 'smooth', block: 'center' });
});
